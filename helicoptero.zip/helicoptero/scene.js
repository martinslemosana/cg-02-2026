// ==================================================
// CLASS - SCENE
// ==================================================

class Scene {

    constructor(gl, program) {

        this.renderer =
            new Renderer(gl, program);

        this.helicopter =
            new Helicopter(0.0,0.0);

        this.setupKeyboard();

        this.tx = 0.0;

        this.ty = 0.0;

        this.speed = 0.05;
    }

    setupKeyboard() {

        document.addEventListener(
            "keydown",
            (event) => {
    
                switch (event.key) {
    
                    case "ArrowRight":
                        this.tx += this.speed;
                        break;
    
                    case "ArrowLeft":
                        this.tx -= this.speed;
                        break;
    
                    case "ArrowUp":
                        this.ty += this.speed;
                        break;
    
                    case "ArrowDown":
                        this.ty -= this.speed;
                        break;
                }
            }
        );
    }

    

    update() {
        this.helicopter.move(
            this.tx,
            this.ty
        );
    }

    draw() {

        gl.clear(
            gl.COLOR_BUFFER_BIT |
            gl.DEPTH_BUFFER_BIT
        );

        gl.useProgram(program);

        this.helicopter.draw(
            this.renderer
        );
    }

    execute() {

        this.update();
        this.draw();

        requestAnimationFrame(
            () => this.execute()
        );
    }

    init() {

        requestAnimationFrame(
            () => this.execute()
        );
    }
}

