// ==================================================
// CLASS - SCENE OBJECT
// ==================================================

class SceneObject {

    constructor(
        vertices,
        colors,
        indices,
    ) {

        this.vertices = vertices;
        this.colors = colors;
        this.indices = indices;

        this.modelTransform = m4.identity();
    }

    updateModelTransform(modelTransform) {

        this.modelTransform =
            modelTransform;
    }

    draw(renderer) {

        renderer.draw(this);
    }
}

class HelicopterBody extends SceneObject{
    constructor(){
        super(
            helicopterBodyGeometry.vertices,
            helicopterBodyGeometry.colors,
            helicopterBodyGeometry.indices
        );
    }
}

class HelicopterTopShaft extends SceneObject{
    constructor(){
        super(
            helicopterTopShaftGeometry.vertices,
            helicopterTopShaftGeometry.colors,
            helicopterTopShaftGeometry.indices
        );
    }
}

class HelicopterTail extends SceneObject{
    constructor(){
        super(
            helicopterTailGeometry.vertices,
            helicopterTailGeometry.colors,
            helicopterTailGeometry.indices
        );
    }
}

class HelicopterPropellers extends SceneObject{
    constructor(){
        super(
            helicopterPropellersGeometry.vertices,
            helicopterPropellersGeometry.colors,
            helicopterPropellersGeometry.indices
        );

        this.theta = 0.0;

        this.angularSpeed = 0.05;
    }

    updateRotation() {

        this.theta += this.angularSpeed;
    }

    updateModelTransform(helicopterModelTransform) {

        const localTransform =
                m4.yRotation(this.theta);

        this.modelTransform =

            m4.multiply(
                helicopterModelTransform,
                localTransform
            );
    }
}

class HelicopterTailPropeller extends SceneObject{
    constructor(){
        super(
            helicopterTailPropellerGeometry.vertices,
            helicopterTailPropellerGeometry.colors,
            helicopterTailPropellerGeometry.indices
        );

        this.theta = 0.0;

        this.angularSpeed = 0.05;
    }

    updateRotation() {

        this.theta += this.angularSpeed;
    }

    updateModelTransform(helicopterModelTransform) {

        const localTransform =

            m4.multiply(
                    m4.translation(0.7,0.0,0.0),
                    m4.multiply(
                        m4.zRotation(this.theta),
                        m4.translation(-0.7,0.0,0.0)
            ));

        this.modelTransform =

            m4.multiply(
                helicopterModelTransform,
                localTransform
            );
    }
}
